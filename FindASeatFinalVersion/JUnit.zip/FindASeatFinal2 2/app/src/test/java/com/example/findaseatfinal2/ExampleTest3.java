package com.example.findaseatfinal2;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.espresso.Espresso;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Assert;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
@Config(sdk = 28)
// Specify one or more SDK version numbers
public class ExampleTest3{
    @Test
    public void emailValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isEmailValid("julian@usc.edu"));
        assertEquals(false, RA.isEmailValid(""));
        assertEquals(false, RA.isEmailValid("julian@usc,ed"));
    }
    @Test
    public void passwordValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, RA.isPasswordValid("hdshjhdhdhhd"));
        assertEquals(false, RA.isPasswordValid("hdhh&"));
        assertEquals(false, RA.isPasswordValid(""));
    }
    @Test
    public void IDValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isIDValid("6745674556"));
        assertEquals(false, RA.isIDValid(""));
        assertEquals(false, RA.isIDValid("1727"));
        assertEquals(false, RA.isIDValid("3783273787327837"));
    }
    @Test
    public void nameValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isNameValid("Julian"));
        assertEquals(false, RA.isNameValid(""));
    }
    @Test
    public void affiliationValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isAffiliationSelected("Graduate"));
        assertEquals(false, RA.isAffiliationSelected("Select:"));

    }
    @Test
    public void loginEmailValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isEmailValid("julian@usc.edu"));
        assertEquals(false, LA.isEmailValid(""));
        assertEquals(false, LA.isEmailValid("j@usc.ed"));

    }
    @Test
    public void loginPasswordValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, LA.isPasswordValid("hdshjdhhdhhd"));
        assertEquals(false, LA.isPasswordValid("hdhh&"));
        assertEquals(false, LA.isPasswordValid(""));

    }

}
