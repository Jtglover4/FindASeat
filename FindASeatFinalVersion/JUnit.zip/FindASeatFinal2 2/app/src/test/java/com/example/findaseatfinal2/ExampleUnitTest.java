package com.example.findaseatfinal2;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void emailValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isEmailValid("julian@usc.edu"));
        assertEquals(false, RA.isEmailValid(""));
        assertEquals(false, RA.isEmailValid("julian@usc,ed"));
    }

    public void passwordValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, RA.isPasswordValid("hdshjhdhdhhd"));
        assertEquals(false, RA.isPasswordValid("hdhh&"));
        assertEquals(false, RA.isPasswordValid(""));
    }

    public void IDValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isIDValid("6745674556"));
        assertEquals(false, RA.isIDValid(""));
        assertEquals(false, RA.isIDValid("1727"));
        assertEquals(false, RA.isIDValid("3783273787327837"));
    }
    public void nameValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isNameValid("Julian"));
        assertEquals(false, RA.isNameValid(""));
    }
    public void affiliationValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isAffiliationSelected("Graduate"));
        assertEquals(false, RA.isAffiliationSelected("Select:"));

    }

    public void loginEmailValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isEmailValid("julian@usc.edu"));
        assertEquals(false, LA.isEmailValid(""));
        assertEquals(false, LA.isEmailValid("j@usc.ed"));

    }

    public void loginPasswordValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, LA.isPasswordValid("hdshjdhhdhhd"));
        assertEquals(false, LA.isPasswordValid("hdhh&"));
        assertEquals(false, LA.isPasswordValid(""));

    }

}