package com.example.findaseatfinal2;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.findaseatfinal2", appContext.getPackageName());
    }
    @Test
    public void emailValidate() {
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        useAppContext();
        RegistrationActivity RA = new RegistrationActivity();


        assertEquals(true, RA.isEmailValid("julian@usc.edu"));
        assertEquals(false, RA.isEmailValid(""));
        assertEquals(false, RA.isEmailValid("julian@usc,ed"));
    }

    public void passwordValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, RA.isPasswordValid("hdshjhdhdhhd"));
        assertEquals(false, RA.isPasswordValid("hdhh&"));
        assertEquals(false, RA.isPasswordValid(""));
    }

    public void IDValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isIDValid("6745674556"));
        assertEquals(false, RA.isIDValid(""));
        assertEquals(false, RA.isIDValid("1727"));
        assertEquals(false, RA.isIDValid("3783273787327837"));
    }
    public void nameValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isNameValid("Julian"));
        assertEquals(false, RA.isNameValid(""));
    }
    public void affiliationValidate() {

        RegistrationActivity RA = new RegistrationActivity();

        assertEquals(true, RA.isAffiliationSelected("Graduate"));
        assertEquals(false, RA.isAffiliationSelected("Select:"));

    }

    public void loginEmailValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isEmailValid("julian@usc.edu"));
        assertEquals(false, LA.isEmailValid(""));
        assertEquals(false, LA.isEmailValid("j@usc.ed"));

    }

    public void loginPasswordValidate(){

        LoginActivity LA = new LoginActivity();

        assertEquals(true, LA.isPasswordValid("djhdhhdshj&"));
        assertEquals(false, LA.isPasswordValid("hdshjdhhdhhd"));
        assertEquals(false, LA.isPasswordValid("hdhh&"));
        assertEquals(false, LA.isPasswordValid(""));

    }
}