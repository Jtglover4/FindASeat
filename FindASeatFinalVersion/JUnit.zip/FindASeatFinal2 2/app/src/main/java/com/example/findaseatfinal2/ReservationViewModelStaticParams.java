package com.example.findaseatfinal2;

public class ReservationViewModelStaticParams {
    public static int buildingID = 1;
    public static boolean canModorCancel = false;
}
