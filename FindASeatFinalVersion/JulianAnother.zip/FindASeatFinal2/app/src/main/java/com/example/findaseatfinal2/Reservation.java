package com.example.findaseatfinal2;

public class Reservation {

    private int resID;
    private int buildingID;
    private boolean indoor;
    private String date;
    private int startTime;
    private int numSlots;

    public Reservation(){

    }

    public Reservation(int resID, int buildingID, boolean indoor, String date, int startTime, int numSlots) {
        this.resID = resID;
        this.buildingID = buildingID;
        this.indoor = indoor;
        this.date = date;
        this.startTime = startTime;
        this.numSlots = numSlots;
    }
    public Reservation(Reservation other) {
        this.resID = other.resID;
        this.buildingID = other.buildingID;
        this.indoor = other.indoor;
        // Strings in Java are immutable, so you can assign the same reference safely
        this.date = other.date;
        this.startTime = other.startTime;
        this.numSlots = other.numSlots;
    }


    public int getResID() {
        return resID;
    }

    public void setResID(int resID) {
        this.resID = resID;
    }

    public int getBuildingID() {
        return buildingID;
    }

    public void setBuildingID(int buildingID) {
        this.buildingID = buildingID;
    }

    public boolean isIndoor() {
        return indoor;
    }

    public void setIndoor(boolean indoor) {
        this.indoor = indoor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getNumSlots() {
        return numSlots;
    }

    public void setNumSlots(int numSlots) {
        this.numSlots = numSlots;
    }

}
