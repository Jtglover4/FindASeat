package com.example.findaseatfinal2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistrationActivity extends AppCompatActivity {

    private final int GALLERY_REQ_CODE = 1000;
    ImageView imgGallery;

    Spinner spinner;
    String[] items = {"Select:", "Undergraduate", "Graduate", "Faculty", "Staff"};

    private EditText emailInput;
    private EditText passwordInput;
    private EditText nameInput;
    private EditText idInput;

    private Button submission;
    private Button goBack;

    private TextView errorEmail;
    private TextView errorPassword;
    private TextView errorName;
    private TextView errorID;
    private TextView errorAffiliation;
    private TextView errorImage;

    LoggedIn currUser = LoggedIn.getInstance();


    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_page);

        imgGallery = findViewById(R.id.imageView);
        Button buttonGallery = findViewById(R.id.button);

        spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

        emailInput = findViewById(R.id.reg_email_tv);
        passwordInput = findViewById(R.id.reg_password_tv);
        nameInput = findViewById(R.id.reg_name_tv);
        idInput = findViewById(R.id.reg_id_tv);

        submission = findViewById(R.id.reg_submit_tv);
        goBack = findViewById(R.id.reg_goback_tv);

        errorEmail = findViewById(R.id.reg_email_error_tv);
        errorPassword = findViewById(R.id.reg_password_error_tv);
        errorName = findViewById(R.id.reg_name_error_tv);
        errorID = findViewById(R.id.reg_id_error_tv);
        errorAffiliation = findViewById(R.id.reg_affiliation_error_tv);
        errorImage = findViewById(R.id.textView16);

        errorEmail.setTextColor(Color.WHITE);
        errorPassword.setTextColor(Color.WHITE);
        errorName.setTextColor(Color.WHITE);
        errorID.setTextColor(Color.WHITE);
        errorAffiliation.setTextColor(Color.WHITE);
        errorImage.setTextColor(Color.WHITE);

        AppCompatActivity this_class = this;

        buttonGallery.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                Intent iGallery = new Intent(Intent.ACTION_PICK);
                iGallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(iGallery, GALLERY_REQ_CODE);

            }
        });

        goBack.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(this_class,Map.class);
                this_class.startActivity(intent);
            }
        });

        submission.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String grabEmail = emailInput.getText().toString();
                String grabPassword = passwordInput.getText().toString();
                String grabName = nameInput.getText().toString();
                String grabID = idInput.getText().toString();

                boolean isError = false;
                if(!checkPasswordGood(grabPassword)){
                    errorPassword.setText("Invalid Password Input");
                    errorPassword.setTextColor(Color.RED);
                    isError = true;
                }else{
                    errorPassword.setTextColor(Color.WHITE);
                }

                if(grabID.length() == 10 && grabID.matches("\\d+")){
                    errorID.setTextColor(Color.WHITE);
                }else{
                    errorID.setText("Invalid ID");
                    errorID.setTextColor(Color.RED);
                    isError = true;
                }

                if(grabName.length() == 0){
                    errorName.setText("Invalid Input");
                    errorName.setTextColor(Color.RED);
                    isError = true;
                }else{
                    errorName.setTextColor(Color.WHITE);
                }

                if(grabEmail.endsWith("@usc.edu")){
                    errorEmail.setTextColor(Color.WHITE);
                }else{
                    errorEmail.setText("Invalid Email");
                    errorEmail.setTextColor(Color.RED);
                    isError = true;

                }

                if((String) spinner.getSelectedItem() == "Select:"){
                    errorAffiliation.setText("Please Select An Affiliation");
                    errorAffiliation.setTextColor(Color.RED);
                    isError = true;
                }else{
                    errorAffiliation.setTextColor(Color.WHITE);
                }

                if (imgGallery.getDrawable() != null) {

                }else{
                    errorImage.setTextColor(Color.RED);
                    errorImage.setText("Please Upload an Image");
                    isError = true;
                }

                if(!isError){
                    //Get the file
                    Drawable drawable = imgGallery.getDrawable(); // Replace 'yourDrawable' with your drawable resource
                    Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                    drawable.draw(canvas);

                    Context applicationContext = getApplicationContext();
                    File file = new File(applicationContext.getFilesDir(), "userupload.png"); // Replace "image.png" with your desired file name
                    try {
                        FileOutputStream fos = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //Upload file to storage, and get URL
                    // Assuming you have a reference to Firebase Storage
                    FirebaseStorage storage = FirebaseStorage.getInstance();
                    StorageReference storageRef = storage.getReference();

// Create a reference to the image file in Firebase Storage
                    StorageReference imageRef = storageRef.child("images/"+ grabID+ ".png");

// Create an upload task
                    UploadTask uploadTask = imageRef.putFile(Uri.fromFile(file));


                    //Made a new uesr, add url, push that user to firebase
                    db = FirebaseFirestore.getInstance();

                    User new_user = new User(
                            Integer.parseInt(grabID),
                            grabName,
                            grabEmail,
                            grabPassword,
                            (String) spinner.getSelectedItem(),
                            new ArrayList<>());
                    addMyUserWithCustomId(grabID, new_user);
                    System.out.println("USER ADDED");
                    currUser.setLoggedIn(true);
                    currUser.setUserID(grabID);
                    Intent intent = new Intent(this_class,Map.class);
                    this_class.startActivity(intent);
                }


            }
        });

    }

    public void addMyUserWithCustomId(String customDocId, User user) {
        db.collection("users").document(customDocId)
                .set(user)
                .addOnSuccessListener(aVoid -> {
                    // Document was successfully added with your custom ID
                    System.out.println("NEW USER MADE");
                })
                .addOnFailureListener(e -> {
                    // Handle the error
                    System.out.println("ERROR OCCURED");
                });
    }

    boolean checkPasswordGood(String s){

        if(s.length() < 8){
            return false;
        }

        String regex = "[^a-zA-Z0-9]";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object
        Matcher matcher = pattern.matcher(s);

        if (matcher.find()) {
            return true;
        } else {
            return false;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK){

            if(requestCode == GALLERY_REQ_CODE){
                imgGallery.setImageURI(data.getData());
            }

        }
    }

}
