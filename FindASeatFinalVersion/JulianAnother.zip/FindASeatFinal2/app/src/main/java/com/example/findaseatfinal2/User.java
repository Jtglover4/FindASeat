package com.example.findaseatfinal2;

import java.util.List;

public class User {

    public int studentID;
    public String name;
    private String email;
    private String password;
    private String affiliation;
    private List<Integer> reservations;

    public User(){

    }

    public User(int studentID, String name, String email, String password, String affiliation, List<Integer> reservations) {
        this.studentID = studentID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.affiliation = affiliation;
        this.reservations = reservations;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public void setAffiliation(String affiliation) {
        this.affiliation = affiliation;
    }

    public List<Integer> getReservations() {
        return reservations;
    }

    public void addReservationID(Integer reservation) {
        reservations.add(reservation);
    }

    public void removeReservationID(Integer reservation) {
        reservations.remove(reservation);
    }

    public void setReservations(List<Integer> reservations) {
        this.reservations = reservations;
    }

    @Override
    public String toString() {
        return "User{" +
                "studentID=" + studentID +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", affiliation='" + affiliation + '\'' +
                ", reservations=" + reservations +
                '}';
    }
}
