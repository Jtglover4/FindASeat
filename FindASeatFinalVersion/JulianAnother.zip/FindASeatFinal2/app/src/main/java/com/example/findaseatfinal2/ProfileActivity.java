//base imports
package com.example.findaseatfinal2;
import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import android.widget.PopupWindow;

import java.util.concurrent.ExecutionException;

//other imports under here

//public class ProfileActivity extends ProfileSubActivity{
public class ProfileActivity extends AppCompatActivity {

    String userEmail = "aaa";
    AppCompatActivity this_class = this;

    User currUser = null;

    LoggedIn currUserL = LoggedIn.getInstance();

    Button modify;
    Button cancel;
    Button modifyYes;
    Button modifyNo;
    TextView popupTitle;

    public void queryUserByEmail(String userEmail) throws InterruptedException, ExecutionException {


        //Task<DataSnapshot> t =  fd.getReference().child("users").get();

        //System.out.println(t.isComplete());


    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page);
        //FirebaseApp.initializeApp(this);
        System.out.println("GETTING UESR");
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        if(currUserL.isLoggedIn() == false){
            Intent intent = new Intent(this_class,LoginActivity.class);
            this_class.startActivity(intent);
            return;
        }
        db.collection("users").document(currUserL.getUserID())// Assumes there's an 'email' field in the document
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if(!(document != null && document.exists())){
                                System.out.println();
                            }
                            User user = document.toObject(User.class);
                            currUser = user;

                            // Additional initialization and logic for your activity
                            TextView leftTab = findViewById(R.id.l_tab);
                            TextView rightTab = findViewById(R.id.r_tab);

                            ImageView image = findViewById(R.id.imageView2);

                            // Add click listeners to the TextViews
                            String URL = "https://firebasestorage.googleapis.com/v0/b/findaseatfinal2.appspot.com/o/images%2F" + currUser.getStudentID() + ".png?alt=media";
                            System.out.println("URL=> " + URL);
                            Picasso.get()
                                    .load(URL)
                                    .into(image);

                            TextView affiliationTextView = findViewById(R.id.textView9);
                            TextView nameTextView = findViewById(R.id.textView12);
                            TextView currentReservationLabel = findViewById(R.id.textView13);
                            TextView currentReservationList = findViewById(R.id.textView14);
                            TextView pastReservationsLabel = findViewById(R.id.textView15);
                            TextView userIDTextView = findViewById(R.id.textView18);
                            TextView reservationDetails = findViewById(R.id.textView17);

                            affiliationTextView.setText("Affiliation: " + currUser.getAffiliation());
                            nameTextView.setText("Name: " + currUser.getName());
                            userIDTextView.setText("ID: " + currUser.getStudentID());

                            modify = findViewById(R.id.button11);
                            cancel = findViewById(R.id.button12);

                            modify.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    View customView = getLayoutInflater().inflate(R.layout.modify_layout, null);
                                    PopupWindow popupWindow = new PopupWindow(customView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
                                    popupWindow.showAtLocation(customView, Gravity.CENTER, 0, 0);

                                    popupTitle = customView.findViewById(R.id.popup_title);

                                    popupTitle.setText("Are you sure you want to do this? Your previous reservation will be cancelled and you will have to make a new one.");


                                    modifyYes = customView.findViewById(R.id.popup_option1);
                                    modifyNo = customView.findViewById(R.id.button13);

                                    modifyNo.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            popupWindow.dismiss();
                                        }
                                    });
                                    modifyYes.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {

                                        }
                                    });

                                }
                            });
                            cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    View customView = getLayoutInflater().inflate(R.layout.modify_layout, null);
                                    PopupWindow popupWindow = new PopupWindow(customView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
                                    popupWindow.showAtLocation(customView, Gravity.CENTER, 0, 0);

                                    popupTitle = customView.findViewById(R.id.popup_title);

                                    popupTitle.setText("Are you sure you want to do this? Your previous reservation will be cancelled.");

                                    modifyYes = customView.findViewById(R.id.popup_option1);
                                    modifyNo = customView.findViewById(R.id.button13);

                                    modifyNo.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            popupWindow.dismiss();
                                        }
                                    });
                                    modifyYes.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {

                                        }
                                    });

                                }
                            });


                            leftTab.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // Handle the click on the left tab
                                    // For example, switch to a different tab or perform some action
                                    // Here, we'll show a toast message as an example
                                    System.out.println("LEFT TAB CLICKED");
                                    Intent intent = new Intent(this_class, Map.class);
                                    this_class.startActivity(intent);
                                }
                            });

                            rightTab.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // Handle the click on the right tab
                                    // For example, switch to a different tab or perform some action
                                    // Here, we'll show a toast message as an example
                                    System.out.println("RIGHT TAB CLICKED");
                                    Intent intent = new Intent(this_class, ProfileActivity.class);
                                    this_class.startActivity(intent);
                                }
                            });
                        } else {
                            Log.w("FB", "Error getting documents.", task.getException());

                        }
                    }

                });
        System.out.println("DONE GETTING");


    }
}

